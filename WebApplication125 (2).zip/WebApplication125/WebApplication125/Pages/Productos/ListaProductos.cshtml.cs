using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http;
using System.Text.Json;
using WebApplication125.Models;
using WebApplication125.Services;

namespace WebApplication125.Pages
{
    public class ListaProductos : PageModel
    {
        private readonly ProductoService _productoService;
        //private readonly ILogger<ListaProductos> _logger;

        public ListaProductos(ProductoService productoService)
        {
            _productoService = productoService;
        }

        public List<ProductoModels> _ProductoModels { get; set; } = new();

        public async Task OnGetAsync()
        {
            _ProductoModels = await _productoService.GetProductosAsync();
        }

    }
}
