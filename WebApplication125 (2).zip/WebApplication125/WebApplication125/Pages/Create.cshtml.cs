using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using WebApplication125.Models;
using WebApplication125.Services;

namespace WebApplication125.Pages
{
    public class CreateModel : PageModel
    {

        private readonly ProductoService _productoService;

        public CreateModel(ProductoService productoService)
        {
            _productoService = productoService;
        }

     
        //Propiedades
        //<td>@itemproducto.Id</td>
        //<td>@itemproducto.Nombre</td>
        //<td>@itemproducto.Descripcion</td>
        //<td>@itemproducto.Precio</td>
        //<td>@itemproducto.Stock</td>
        [BindProperty]
        public ProductoModels _ProductoModel { get; set; } = new();

        public string Mensaje { get; set; } = string.Empty;
        //Post
        public async Task<IActionResult> OnPostAsync()
        {

            try
            {
                //la equivalencia 
                if (!ModelState.IsValid)
                {
                    Mensaje = "Datos Invalidos";
                    return Page();
                }

                //{
                //                "id": 0,
                //  "nombre": "string",
                //  "descripcion": "string",
                //  "precio": 0,
                //  "stock": 0
                //}

                var response = await _productoService.AddProductosAsync(_ProductoModel);

                if (response)
                {
                    Mensaje = "Producto agregado";
                    return RedirectToPage("Index");
                }
                else
                {
                    Mensaje = "Error en el agregado del producto";
                    return Page();
                }
            }
            catch (Exception ex)
            {
                Mensaje = "Error " + ex.Message;
                return Page();
            }

         

        }

    }
}
