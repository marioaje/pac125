using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebApplication125.Models;
using WebApplication125.Services;

namespace WebApplication125.Pages
{
    public class DeleteModel : PageModel
    {


        private readonly ProductoService _productoService;

        public DeleteModel(ProductoService productoService)
        {
            _productoService = productoService;
        }

        [BindProperty]
        public ProductoModels _ProductoModel { get; set; } = new();

        public string Mensaje { get; set; } = string.Empty;
        public async Task<IActionResult> OnGetAsync(int id)
        {
            var productos = await _productoService.GetProductosAsync();
            _ProductoModel = productos.FirstOrDefault( p => p.Id == id);
            if (_ProductoModel == null) { 
                return NotFound();
            }

            return Page();
            
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var response = await _productoService.DeleteProductosAsync(_ProductoModel.Id);

            if (response)
            {
                return RedirectToPage("Index");
            }
            else
            {
                Mensaje = "Error al eliminar el producto";
                return Page();
            }

        }


    }
}
