using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication125.Pages
{
    public class IntegrantesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
