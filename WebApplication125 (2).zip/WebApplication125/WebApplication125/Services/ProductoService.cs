﻿using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json;
using WebApplication125.Models;

namespace WebApplication125.Services
{

    //Es la seccion que me permite consumir el API u otros servicios
    public class ProductoService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiUrl;

        public ProductoService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _apiUrl = configuration["ApiUrl"] + "Product/";
            //  "ApiUrl": "https://localhost:7114/api/Product/"
        }

        public async Task<List<ProductoModels>> GetProductosAsync()
        {
            var response = await _httpClient.GetAsync(_apiUrl);
            if (!response.IsSuccessStatusCode)
                return new List<ProductoModels>();//aca viene como un objeto 
            var json = await response.Content.ReadAsStringAsync();
            //aca lo convertimos en un sring para JSON

            return JsonSerializer.Deserialize<List<ProductoModels>>(json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                }
            ) ?? new List<ProductoModels>();
            //return await _context.Productos.ToListAsync();
            //// return _productoService.GetProductos();
        }


        public async Task<bool> AddProductosAsync(ProductoModels productos)
        {
            var jsonProductos = JsonSerializer.Serialize(productos);
            var content = new StringContent(jsonProductos, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(_apiUrl, content);

            return response.IsSuccessStatusCode;

        }

        public async Task<bool> DeleteProductosAsync(int id)
        {

            var response = await _httpClient.DeleteAsync($"{_apiUrl}{id}");

            return response.IsSuccessStatusCode;

        }

        public async Task<bool> UpdateProductosAsync(ProductoModels productos)
        {
            var jsonProductos = JsonSerializer.Serialize(productos);
            var content = new StringContent(jsonProductos, Encoding.UTF8, "application/json");
            //  "ApiUrl": "https://localhost:7114/api/Product/85"
            var response = await _httpClient.PutAsync($"{_apiUrl}{productos.Id}", content);

            return response.IsSuccessStatusCode;

        }
        

    }
    }
