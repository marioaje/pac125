﻿using System.ComponentModel.DataAnnotations;

namespace Api31.Models
{
    public class Productos
    {
        //Aca nosotros creamos nuestra capa de modelo de datos
        //Atributos
        [Key]
        public int Id { get; set; }

        public string Nombre { get; set; } = string.Empty;

        public string Descripcion { get; set; } = string.Empty ;

        public decimal Precio { get; set; }

        public int Stock { get; set; }
    }
}
