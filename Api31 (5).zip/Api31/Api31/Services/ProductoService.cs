﻿using Api31.Models;

namespace Api31.Services
{
    public class ProductoService
    {
        //Aca tenemos la interacion de la base de datos o almacenamiento
        private readonly List<Productos> _productos = new List<Productos> ();
        private int _nextId =1 ;

        //Obt Productos
        public List<Productos> GetProductos()
        {
            return _productos;
        }


        //Obtener un producto por ID???
        public Productos GetProductosById( int Id)
        {
            return _productos.FirstOrDefault(p => p.Id == Id);
        }

        //Agregar datos
        public Productos AddProductos(Productos productos)
        {            
            productos.Id = _nextId++;
            _productos.Add(productos);//Aca insertamos el dato
            return productos;
        }

        //Actualizar
        public bool UpdateProductos(Productos productos)
        {
            var existe = _productos.FirstOrDefault(p => p.Id == productos.Id);

            if (existe == null) return false;//Devuele sino existe


            existe.Nombre = productos.Nombre;
            existe.Precio = productos.Precio;
            existe.Descripcion = productos.Descripcion;
            existe.Stock = productos.Stock;
 
            return true;
        }

        //Eliminar
        public bool DeleteProductos(int Id)
        {
            var existe = _productos.FirstOrDefault(p => p.Id == Id);

            if (existe == null) return false;//Devuele sino existe

            _productos.Remove(existe);                

            return true;
        }

    }
}
