﻿using Api31.Data;
using Api31.Models;
using Api31.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api31.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly AplicationDbContext _context;

        //Iniciamos con todo el AplicationDbContext, en el cosntructor
        public ProductController (AplicationDbContext context)
        {
            _context = context;
        }

        //Obtenemos productos


        //El GET
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Productos>>> GetProductos()
        {
            return await _context.Productos.ToListAsync();
           // return _productoService.GetProductos();
        }

        //El GET ID
        [HttpGet("{id}")]
        public async Task<ActionResult<Productos>> GetProductos(int id)
        {

            var producto = await _context.Productos.FindAsync(id);

            if (producto == null)
            {
                return NotFound(
                        new
                        {
                            mensaje = "Producto no encontrado"
                        }
                    );
            }
            return producto;
        }

        //Un ejemplo cuando esta mal hecho
        //public async Task<ActionResult<Productos>> GetProductos(string id)
        //{
         //1' or 1 == 1; --
        //var scriptSQL =  " Select * from Productos where id = "+id+";"

        //    var producto = await _context.Productos.FindAsync(id);

        //    if (producto == null)
        //    {
        //        return NotFound(
        //                new
        //                {
        //                    mensaje = "Producto no encontrado"
        //                }
        //            );
        //    }
        //    return producto;
        //}


        ////El POST
        [HttpPost]
        public async Task<ActionResult<Productos>> AddProductos(Productos productos)
        {

            _context.Productos.Add(productos);
            await _context.SaveChangesAsync();

            return
                CreatedAtAction(
                        nameof(GetProductos), new
                        {
                            id = productos.Id
                        },
                        productos);


            //var newProducto = _productoService.AddProductos(productos);


            //return
            //    CreatedAtAction(
            //            nameof(GetProductos), new
            //            {
            //                id = newProducto.Id
            //            },
            //            newProducto);

        }




        //El PUT
        //Permite actualizar el registro
        [HttpPut("{id}")]
        public async Task<ActionResult<Productos>> UpdateProductos(int id, Productos productos)
        {
            if (productos == null)
            {
                return BadRequest();
            }

            _context.Entry(productos).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                if ( !_context.Productos.Any(p => p.Id == id))
                    {
                    return NotFound(
                            new
                            {
                                elmensaje = "El producto no esta"
                            }
                        );
                    }
                else
                {
                    throw;
                }
            }

            //if (!_productoService.UpdateProductos(productos))
            //{
            //    return NotFound(
            //            new
            //            {
            //                elmensaje = "El producto no esta"
            //            }
            //        );
            //}
            return NoContent();
        }

        //El Delete
        //Borra un registro
        [HttpDelete("{id}")]        
        public async Task<ActionResult> DeleteProductos(int id)
        {
            var producto  = await _context.Productos.FindAsync(id);

            if (producto == null)
            {
                return NotFound(
                        new
                        {
                            elmensaje = "El producto no esta"
                        }
                    );
            }

            _context.Productos.Remove(producto);
            await _context.SaveChangesAsync();
            return NoContent();

            //if (!_productoService.DeleteProductos(id))
            //{
            //    return NotFound(
            //            new
            //            {
            //                elmensaje = "El producto no esta"
            //            }
            //        );
            //}
            //return NoContent();
        }





    }
}
