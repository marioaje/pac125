﻿using Api31.Models;
using Api31.Services;
using Microsoft.AspNetCore.Mvc;

namespace Api31.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductosController : ControllerBase
    {
        //Routes de acceso o GET, POST, DELETE PUT

        private readonly ProductoService _productoService;

        //Aca inicializo mi clase o constructor 
        public ProductosController(ProductoService productoService)
        {
            _productoService = productoService;
        }


        //El GET
        [HttpGet]
        public ActionResult<List<Productos>> GetProductos()
        {
            return _productoService.GetProductos();
        }

        //El GET ID
        [HttpGet("{id}")]
        public ActionResult<Productos> GetProductos(int id)
        {

            var producto = _productoService.GetProductosById(id);

            if (producto == null)
            {
                return NotFound(
                        new
                        {
                            mensaje = "Producto no encontrado"
                        }
                    );
            }
            return producto;
        }


        //El POST
        [HttpPost]
        public ActionResult<Productos> AddProductos(Productos productos)
        {

            var newProducto = _productoService.AddProductos(productos);


            return
                CreatedAtAction(
                        nameof(GetProductos), new
                        {
                            id = newProducto.Id
                        },
                        newProducto);

        }




        //El PUT
        //Permite actualizar el registro
        [HttpPut]
        public IActionResult UpdateProductos(Productos productos)
        {

            if (!_productoService.UpdateProductos(productos))
            {
                return NotFound(
                        new
                        {
                            elmensaje = "El producto no esta"
                        }
                    );
            }
            return NoContent();
        }

        //El Delete
        //Borra un registro
        [HttpDelete]
        [Route("noesproducto/borrando")]
        public IActionResult DeleteProductos(int id)
        {

            if (!_productoService.DeleteProductos(id))
            {
                return NotFound(
                        new
                        {
                            elmensaje = "El producto no esta"
                        }
                    );
            }
            return NoContent();
        }




    }
}

